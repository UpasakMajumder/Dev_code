-- HF10-3 - Update forums layout customization options
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 1
BEGIN
	DECLARE @webPartProperties xml;
	DECLARE @exists bit;

	-- Update 'Forum search results' web part
	-- Store current properties definition of the web part
	SELECT @webPartProperties = [WebPartProperties] FROM [CMS_WebPart] WHERE [WebPartGUID] = '8E8C505C-DBE5-4DB7-9827-FF1ADD8EA23A';

	-- Check existence of elements other than 'controlname'
	SET @exists = @webPartProperties.exist('form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

	IF (@exists = 1)
	BEGIN
		-- Delete elements other than 'controlname'
		SET @webPartProperties.modify('delete form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

		-- Update properties definition of the web part
		UPDATE [CMS_WebPart] SET [WebPartProperties] = CONVERT(nvarchar(max), @webPartProperties) WHERE [WebPartGUID] = '8E8C505C-DBE5-4DB7-9827-FF1ADD8EA23A';
	END


	-- Update 'Forum group' web part
	-- Store current properties definition of the web part
	SELECT @webPartProperties = [WebPartProperties] FROM [CMS_WebPart] WHERE [WebPartGUID] = 'D0FAA3C9-62B9-4C90-800E-78C1FA496EBB';

	-- Check existence of elements other than 'controlname'
	SET @exists = @webPartProperties.exist('form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

	IF (@exists = 1)
	BEGIN
		-- Delete elements other than 'controlname'
		SET @webPartProperties.modify('delete form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

		-- Update properties definition of the web part
		UPDATE [CMS_WebPart] SET [WebPartProperties] = CONVERT(nvarchar(max), @webPartProperties) WHERE [WebPartGUID] = 'D0FAA3C9-62B9-4C90-800E-78C1FA496EBB';
	END


	-- Update 'Forum (Single forum - General)' web part
	-- Store current properties definition of the web part
	SELECT @webPartProperties = [WebPartProperties] FROM [CMS_WebPart] WHERE [WebPartGUID] = '2211EAAB-2A15-4765-9643-D4E9B3F57FF2';

	-- Check existence of elements other than 'controlname'
	SET @exists = @webPartProperties.exist('form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

	IF (@exists = 1)
	BEGIN
		-- Delete elements other than 'controlname'
		SET @webPartProperties.modify('delete form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

		-- Update properties definition of the web part
		UPDATE [CMS_WebPart] SET [WebPartProperties] = CONVERT(nvarchar(max), @webPartProperties) WHERE [WebPartGUID] = '2211EAAB-2A15-4765-9643-D4E9B3F57FF2';
	END


	-- Update 'Group forum list' web part
	-- Store current properties definition of the web part
	SELECT @webPartProperties = [WebPartProperties] FROM [CMS_WebPart] WHERE [WebPartGUID] = 'C420AFA3-F5FA-4986-BFE6-1EFC34D3B7EB';

	-- Check existence of elements other than 'controlname'
	SET @exists = @webPartProperties.exist('form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

	IF (@exists = 1)
	BEGIN
		-- Delete elements other than 'controlname'
		SET @webPartProperties.modify('delete form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

		-- Update properties definition of the web part
		UPDATE [CMS_WebPart] SET [WebPartProperties] = CONVERT(nvarchar(max), @webPartProperties) WHERE [WebPartGUID] = 'C420AFA3-F5FA-4986-BFE6-1EFC34D3B7EB';
	END


	-- Update 'Group forum search results' web part
	-- Store current properties definition of the web part
	SELECT @webPartProperties = [WebPartProperties] FROM [CMS_WebPart] WHERE [WebPartGUID] = 'CEAF7D88-38D9-49C3-AF75-A92BC7E4B0CC';

	-- Check existence of elements other than 'controlname'
	SET @exists = @webPartProperties.exist('form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

	IF (@exists = 1)
	BEGIN
		-- Delete elements other than 'controlname'
		SET @webPartProperties.modify('delete form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

		-- Update properties definition of the web part
		UPDATE [CMS_WebPart] SET [WebPartProperties] = CONVERT(nvarchar(max), @webPartProperties) WHERE [WebPartGUID] = 'CEAF7D88-38D9-49C3-AF75-A92BC7E4B0CC';
	END
END
GO


-- HF10-55 - Coupon code uses count null values changed to 0
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 10
BEGIN
	UPDATE [COM_MultiBuyCouponCode] SET [MultiBuyCouponCodeUseCount] = 0
		WHERE [MultiBuyCouponCodeUseCount] IS NULL

	UPDATE [COM_CouponCode] SET [CouponCodeUseCount] = 0
		WHERE [CouponCodeUseCount] IS NULL
END
GO
/* ----------------------------------------------------------------------------*/
/* This SQL command must be at the end and must contain current hotfix version */
/* ----------------------------------------------------------------------------*/
UPDATE [CMS_SettingsKey] SET KeyValue = '14' WHERE KeyName = N'CMSHotfixVersion'
GO
