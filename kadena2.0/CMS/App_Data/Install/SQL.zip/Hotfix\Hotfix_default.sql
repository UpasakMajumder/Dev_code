-- HF10-3 - Update forums layout customization options
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 1
BEGIN
	DECLARE @webPartProperties xml;
	DECLARE @exists bit;

	-- Update 'Forum search results' web part
	-- Store current properties definition of the web part
	SELECT @webPartProperties = [WebPartProperties] FROM [CMS_WebPart] WHERE [WebPartGUID] = '8E8C505C-DBE5-4DB7-9827-FF1ADD8EA23A';

	-- Check existence of elements other than 'controlname'
	SET @exists = @webPartProperties.exist('form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

	IF (@exists = 1)
	BEGIN
		-- Delete elements other than 'controlname'
		SET @webPartProperties.modify('delete form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

		-- Update properties definition of the web part
		UPDATE [CMS_WebPart] SET [WebPartProperties] = CONVERT(nvarchar(max), @webPartProperties) WHERE [WebPartGUID] = '8E8C505C-DBE5-4DB7-9827-FF1ADD8EA23A';
	END


	-- Update 'Forum group' web part
	-- Store current properties definition of the web part
	SELECT @webPartProperties = [WebPartProperties] FROM [CMS_WebPart] WHERE [WebPartGUID] = 'D0FAA3C9-62B9-4C90-800E-78C1FA496EBB';

	-- Check existence of elements other than 'controlname'
	SET @exists = @webPartProperties.exist('form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

	IF (@exists = 1)
	BEGIN
		-- Delete elements other than 'controlname'
		SET @webPartProperties.modify('delete form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

		-- Update properties definition of the web part
		UPDATE [CMS_WebPart] SET [WebPartProperties] = CONVERT(nvarchar(max), @webPartProperties) WHERE [WebPartGUID] = 'D0FAA3C9-62B9-4C90-800E-78C1FA496EBB';
	END


	-- Update 'Forum (Single forum - General)' web part
	-- Store current properties definition of the web part
	SELECT @webPartProperties = [WebPartProperties] FROM [CMS_WebPart] WHERE [WebPartGUID] = '2211EAAB-2A15-4765-9643-D4E9B3F57FF2';

	-- Check existence of elements other than 'controlname'
	SET @exists = @webPartProperties.exist('form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

	IF (@exists = 1)
	BEGIN
		-- Delete elements other than 'controlname'
		SET @webPartProperties.modify('delete form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

		-- Update properties definition of the web part
		UPDATE [CMS_WebPart] SET [WebPartProperties] = CONVERT(nvarchar(max), @webPartProperties) WHERE [WebPartGUID] = '2211EAAB-2A15-4765-9643-D4E9B3F57FF2';
	END


	-- Update 'Group forum list' web part
	-- Store current properties definition of the web part
	SELECT @webPartProperties = [WebPartProperties] FROM [CMS_WebPart] WHERE [WebPartGUID] = 'C420AFA3-F5FA-4986-BFE6-1EFC34D3B7EB';

	-- Check existence of elements other than 'controlname'
	SET @exists = @webPartProperties.exist('form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

	IF (@exists = 1)
	BEGIN
		-- Delete elements other than 'controlname'
		SET @webPartProperties.modify('delete form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

		-- Update properties definition of the web part
		UPDATE [CMS_WebPart] SET [WebPartProperties] = CONVERT(nvarchar(max), @webPartProperties) WHERE [WebPartGUID] = 'C420AFA3-F5FA-4986-BFE6-1EFC34D3B7EB';
	END


	-- Update 'Group forum search results' web part
	-- Store current properties definition of the web part
	SELECT @webPartProperties = [WebPartProperties] FROM [CMS_WebPart] WHERE [WebPartGUID] = 'CEAF7D88-38D9-49C3-AF75-A92BC7E4B0CC';

	-- Check existence of elements other than 'controlname'
	SET @exists = @webPartProperties.exist('form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

	IF (@exists = 1)
	BEGIN
		-- Delete elements other than 'controlname'
		SET @webPartProperties.modify('delete form/field[@column="ForumViewMode"]/settings/*[local-name() != "controlname"]');

		-- Update properties definition of the web part
		UPDATE [CMS_WebPart] SET [WebPartProperties] = CONVERT(nvarchar(max), @webPartProperties) WHERE [WebPartGUID] = 'CEAF7D88-38D9-49C3-AF75-A92BC7E4B0CC';
	END
END
GO


-- HF10-55 - Coupon code uses count null values changed to 0
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 10
BEGIN
	UPDATE [COM_MultiBuyCouponCode] SET [MultiBuyCouponCodeUseCount] = 0
		WHERE [MultiBuyCouponCodeUseCount] IS NULL

	UPDATE [COM_CouponCode] SET [CouponCodeUseCount] = 0
		WHERE [CouponCodeUseCount] IS NULL
END

GO


-- HF10-101 - Fix incorrect FileMetaFileGUIDs for cloned SKUFiles
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 19
BEGIN
	UPDATE [COM_SKUFile]
	SET [FileMetaFileGUID] = B.[MetaFileGUID]
	FROM [COM_SKUFile] A
	INNER JOIN [CMS_MetaFile] B
		ON A.[FileSKUID] = B.[MetaFileObjectID] AND A.[FileName] = B.[MetaFileName]
	WHERE
	B.[MetaFileObjectType] = 'ecommerce.sku' AND B.[MetaFileGroupName] = 'E-product' AND [FileMetaFileGUID] != B.[MetaFileGUID]
END

GO


-- HF10-118 - Fix incorrect query for Conversion Details report
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 23
BEGIN
	UPDATE Reporting_ReportTable
	SET TableQuery =
'SET @FromDate = {%DatabaseSchema%}.Func_Analytics_DateTrim(@FromDate,''day''); 
SET @ToDate = {%DatabaseSchema%}.Func_Analytics_EndDateTrim(@ToDate,''day''); 

IF (@ConversionName IS NULL OR @ConversionName = '''') BEGIN

  SELECT TOP 100 
    ConversionDisplayName AS ''{$reports_conversion.name_header$}'', 
    SUM(HitsCount) AS ''{$reports_conversion.hits_header$}'',
    SUM(HitsValue) AS ''{$reports_conversion.value_header$}''
  FROM Analytics_Statistics
  JOIN Analytics_DayHits ON HitsStatisticsID = StatisticsID
  JOIN Analytics_Conversion ON ConversionName = StatisticsObjectName AND ConversionSiteID = @CMSContextCurrentSiteID
  WHERE 
    (StatisticsSiteID = @CMSContextCurrentSiteID)
    AND (StatisticsCode=N''conversion'') 
    AND (StatisticsID = HitsStatisticsID) 
    AND (@FromDate IS NULL OR HitsStartTime >= @FromDate) 
    AND (@ToDate IS NULL OR HitsEndTime <= @ToDate)	
  GROUP BY ConversionDisplayName 
  ORDER BY SUM(HitsCount) DESC

END

ELSE BEGIN
  
  SELECT
    ISNULL(SUM(HitsCount),0) AS ''{$conversion.conversion.list$}'',
    ISNULL(SUM (HitsValue),0) AS ''{$conversions.value$}''
  FROM Analytics_Statistics
  JOIN Analytics_DayHits ON HitsStatisticsID = StatisticsID
  WHERE 
    StatisticsObjectName = @ConversionName 
    AND StatisticsSiteID = @CMSContextCurrentSiteID 
    AND StatisticsCode=N''conversion''
    AND (@FromDate IS NULL OR HitsStartTime >= @FromDate)
    AND (@ToDate IS NULL OR HitsEndTime <= @ToDate)

END'
	WHERE TableGUID = 'F95992D3-EBEB-44C2-9B58-82A6523367ED'
END

GO


-- HF10-227 - Contact data overwrite disabled after upgrade to K10
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 47
BEGIN
	DECLARE @classResourceID int;
	SET @classResourceID = (SELECT TOP 1 [ResourceID] FROM [CMS_Resource] WHERE [ResourceGUID] = 'd4b7561a-f188-420c-8f68-63b5c573b2bf')
	
	IF @classResourceID IS NOT NULL BEGIN
		UPDATE [CMS_Class] SET [ClassContactOverwriteEnabled] = 1
		WHERE [ClassGUID] = '2e02c378-0f3d-45de-9b2d-b8cf2bd87b55' AND [ClassInheritsFromClassID] IS NULL AND (';' + ClassCustomizedColumns + ';' NOT LIKE '%;ClassContactOverwriteEnabled;%')

	END
END

GO


-- PLATFORM-11647 - Fix possible SQLi in UI elements
DECLARE @HOTFIXVERSION INT;
SET @HOTFIXVERSION = (SELECT [KeyValue] FROM [CMS_SettingsKey] WHERE [KeyName] = N'CMSHotfixVersion')
IF @HOTFIXVERSION < 51
BEGIN
	-- Update 'Groups.EditGroup.Forums' UI Element
	UPDATE [CMS_UIElement] SET [ElementProperties] = '<Data><DisplayBreadcrumbs>False</DisplayBreadcrumbs><EditInDialog>False</EditInDialog><includejquery>False</includejquery><ObjectType>forums.groupforumgroup</ObjectType><OpenInDialog>False</OpenInDialog><ParentObjectType>community.group</ParentObjectType><TitleText>{$forumgrouplist.headerforumgrouplist$}</TitleText><WhereCondition>(GroupSiteID = {% CMSContext.CurrentSiteID @%}) and (GroupGroupID = {? ToInt(parentobjectid, 0) ?})</WhereCondition></Data>'
	WHERE [ElementGUID] = '265B0EE1-09C5-4C29-84D3-816F96960AAE';

	-- Update 'GroupForumGroupEditTab_Forums' UI Element
	UPDATE [CMS_UIElement] SET [ElementProperties] = '<Data><DisplayBreadcrumbs>False</DisplayBreadcrumbs><EditInDialog>False</EditInDialog><includejquery>False</includejquery><ObjectType>forums.groupforum</ObjectType><OpenInDialog>False</OpenInDialog><ParentObjectType>forums.groupforumgroup</ParentObjectType><WhereCondition>ForumGroupID = {? ToInt(parentobjectid, 0) ?}</WhereCondition></Data>'
	WHERE [ElementGUID] = 'DE463408-6153-447B-B7AC-785479D98087';

	-- Update 'ForumGroupEditTab_Forums' UI Element
	UPDATE [CMS_UIElement] SET [ElementProperties] = '<Data><DisplayBreadcrumbs>False</DisplayBreadcrumbs><displaytitle>false</displaytitle><EditInDialog>False</EditInDialog><includejquery>False</includejquery><ObjectType>forums.forum</ObjectType><OpenInDialog>False</OpenInDialog><ParentObjectType>forums.forumgroup</ParentObjectType><WhereCondition>ForumGroupID = {? ToInt(parentobjectid, 0) ?}</WhereCondition></Data>'
	WHERE [ElementGUID] = 'DF0A9A45-1983-4414-ADE6-6C2AC398CD90';

	-- Update 'AdditionalLibraries' UI Element
	UPDATE [CMS_UIElement] SET [ElementProperties] = '<Data><DisplayBreadcrumbs>False</DisplayBreadcrumbs><EditInDialog>False</EditInDialog><includejquery>False</includejquery><ObjectType>cms.resourcelibrary</ObjectType><OpenInDialog>False</OpenInDialog><OrderBy>ResourceLibraryPath</OrderBy><PageExtenderAssemblyName>App_Code</PageExtenderAssemblyName><PageExtenderClassName>ModuleLibrariesExtender</PageExtenderClassName><WhereCondition>ResourceLibraryResourceID = {? ToInt(parentobjectid, 0) ?}</WhereCondition></Data>'
	WHERE [ElementGUID] = '64666D94-F4A2-4ED7-9D6D-B96A2168164D';

	-- Update 'Modules.UserInterface.HelpTopic' UI Element
	UPDATE [CMS_UIElement] SET [ElementProperties] = '<Data><DisplayBreadcrumbs>False</DisplayBreadcrumbs><displaytitle>false</displaytitle><EditInDialog>False</EditInDialog><ExtenderClassName>HelpTopicUniGridExtender</ExtenderClassName><GridExtender>App_Code</GridExtender><includejquery>False</includejquery><ObjectType>cms.helptopic</ObjectType><OpenInDialog>False</OpenInDialog><WhereCondition>HelpTopicUIElementID = {? ToInt(parentobjectid, 0) ?}</WhereCondition></Data>'
	WHERE [ElementGUID] = '60BAB586-8437-43DB-8377-F2D6987B2742';
	
	-- Update 'EditLibraryFiles' UI Element
	UPDATE [CMS_UIElement] SET [ElementProperties] = '<Data><DisplayBreadcrumbs>False</DisplayBreadcrumbs><EditInDialog>False</EditInDialog><ExtenderClassName>SharePointFileGridExtender</ExtenderClassName><GridExtender>App_Code</GridExtender><includejquery>False</includejquery><ObjectType>sharepoint.sharepointfile</ObjectType><OpenInDialog>False</OpenInDialog><WhereCondition>SharePointFileSharePointLibraryID = {? ToInt(parentobjectid, 0) ?}</WhereCondition></Data>'
	WHERE [ElementGUID] = '83D7193B-8A55-4E8E-8979-B31A9788A01D';

	-- Update 'WebPartContainer.Sites' UI Element
	UPDATE [CMS_UIElement] SET [ElementProperties] = '<Data><bindingobjectprovidertype>CMS.WebPartContainerSite</bindingobjectprovidertype><BindingObjectType>cms.webpartcontainersite</BindingObjectType><checkmodifypermission>True</checkmodifypermission><DisplayBreadcrumbs>False</DisplayBreadcrumbs><includejquery>False</includejquery><ListPrefaceText>{$webcontainers_edit_sites.sitetitle$}</ListPrefaceText><ResourcePrefix>siteselect</ResourcePrefix><WhereCondition>ContainerID = {? ToInt(objectID, 0) ?}</WhereCondition></Data>'
	WHERE [ElementGUID] = '13FAA3EF-8ABE-42BC-BAE7-0A70251FA480';
END
GO

/* ----------------------------------------------------------------------------*/
/* This SQL command must be at the end and must contain current hotfix version */
/* ----------------------------------------------------------------------------*/
UPDATE [CMS_SettingsKey] SET KeyValue = '51' WHERE KeyName = N'CMSHotfixVersion'
GO
